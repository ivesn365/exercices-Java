package Esis;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i, k, l, j;
		i = 5;
		k = 6;
		l = 2;
		j = 7;
		int h = (i+k)-(l*j);
		System.out.println("h vaut : "+h);
		

	}

}
