
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.WindowConstants;



public class Fen extends JFrame implements ActionListener{
	JButton suiv = new JButton("Cliquer");
	JButton prec = new JButton("Précedent");
	JTextField display = new JTextField("");
	JLabel label = new JLabel("Citation du jour");
	Etoile etoile = new Etoile(5);
	JTextPane text = new JTextPane();
	
	JColorChooser colorchooser = new JColorChooser(); 
	JDialog about = new JDialog(this); 
	JMenuBar menubar = new JMenuBar(); 
	JPanel conteneur = new JPanel();
	private JSplitPane split, split2;
	
	// ImagePanel panel = new ImagePanel(new ImageIcon("im.jpeg").getImage());

	JMenu [] menus = new JMenu[] {
		new JMenu("File"),
		new JMenu("Aide")
	};
	
	JMenuItem menuitems [][] = new JMenuItem[][]{{
		new JMenuItem("Changer la police"), 
		new JMenuItem("Changer Couleur"),
		new JMenuItem("Partager"), 
		new JMenuItem("Exit")},{
		new JMenuItem("Développer par Ives")}
	};
	Font font = new Font("Consolas", Font.BOLD, 12),
			font2 = new Font("Consolas",Font.ITALIC, 12),
			font3 =new Font("Consolas", Font.CENTER_BASELINE, 12);
	
	public Fen() {
		super("Citation du jour v1.0");
		
		initMenu();		
		display.setFont(font);
		suiv.setFont(font);
		prec.setFont(font);
		JPanel pnlHead = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
		JPanel pnlBody = new JPanel(new GridLayout(2, 2));
		JPanel pnlTbody = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 30)),
				p = new JPanel();
	
		JLabel label2 = new JLabel();
		label.setFont(font);
		text.setFont(font2);
		
		FichierLire fichier = new FichierLire();
		nbre = Math.random() * fichier.mots.size();
	    int nbre1 = (int)nbre;
		
		String dDisplay = String.valueOf(display.getText());
		text.setText(fichier.toString(nbre1));
		
		
		text.setForeground (Color.BLUE);
		pnlBody.add(label, BorderLayout.NORTH);
		pnlBody.add(etoile, new GridLayout(3,4));
		pnlBody.add(label2);
		pnlBody.add(text);
		pnlTbody.add(suiv, BorderLayout.EAST);
		
		
		split2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, pnlBody, pnlTbody);
		this.getContentPane().add(split2, BorderLayout.CENTER);
		/*getContentPane().setLayout(new BorderLayout());
		getContentPane().add(BorderLayout.NORTH, pnlHead);
		getContentPane().add(BorderLayout.CENTER, pnlBody);
		getContentPane().add(BorderLayout.SOUTH, pnlTbody);*/
		
		
		
		
		
		suiv.addActionListener(this);
		prec.addActionListener(this);
		conteneur.setSize(500, 280);
		this.setLocationRelativeTo(null);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setSize(500, 300);
		setVisible(true);
		setResizable(false);
	}
	//Jitems menuItem = new Jitems();
	void initMenu(){ 
		
		for( int i=0; i<menus.length; i++ ) {
			menubar.add( menus[i] );
			for( int j=0; j<menuitems[i].length; j++ ){
				menus[i].add( menuitems[i][j] );
				menuitems[i][j].addActionListener(action);
			}
		}
		this.setJMenuBar( menubar );
		}
	
	double nbre;

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		JButton source = (JButton)e.getSource();
		String cmd = e.getActionCommand();
		if(source == suiv) changeMot();	
		
		
	}
	boolean isFirstDigit = true;
	
	ActionListener action = new ActionListener(){ //Classe anonime
		public void actionPerformed( ActionEvent e ){
			JMenuItem mi = (JMenuItem)e.getSource();
			String id = mi.getText();
			nbre = Math.random() * 3;
		    int nbre1 = (int)nbre;
			if( id.equals("Changer Couleur")) {
				
			    if(nbre1 == 0)text.setForeground (Color.green);
			    else if(nbre1 == 1)text.setForeground (Color.black);
			    else if(nbre1 == 2)text.setForeground (Color.red);
			    else text.setForeground (Color.blue);
				
				}
			if(id.equals("Changer la police"))text.setFont(font3);
			else if( id.equals("Exit")){
				System.exit(0);
			}
		}
    };
	
	public void changeMot() {
		FichierLire fichier = new FichierLire();
		nbre = Math.random() * fichier.mots.size();
	    int nbre1 = (int)nbre;
		
		String dDisplay = String.valueOf(display.getText());
		text.setText(fichier.toString(nbre1));
		isFirstDigit = true;
	}
	
	public void precedent() {
		int nbre1 =(int)nbre;
		FichierLire fichier = new FichierLire();
		String dDisplay = String.valueOf(display.getText());
		text.setText(fichier.toString(nbre1));
		isFirstDigit = true;
	}
	
	/*class ImagePanel extends JPanel {

	     private Image img;

	     public ImagePanel(String img) {
	       this(new ImageIcon(img).getImage());
	     }

	     public ImagePanel(Image img) {
	       this.img = img;
	       Dimension size = new Dimension(img.getWidth(null), img.getHeight(null));
	       setPreferredSize(size);
	       setMinimumSize(size);
	       setMaximumSize(size);
	       setSize(size);
	       setLayout(null);
	     }

	     public void paintComponent(Graphics g) {
	       g.drawImage(img, 0, 0, null);
	     }
	} */
	
	public static void main(String[] args) {
		Fen c = new Fen(); 
		
	}


}
