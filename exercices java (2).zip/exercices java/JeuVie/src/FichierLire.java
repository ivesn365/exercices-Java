
import java.io.*;
import java.util.ArrayList;
import java.util.List;
public class FichierLire{
	List<String> mots = new ArrayList();
	
  public FichierLire()
  {
    try
    {
      // Le fichier d'entrée
    	
      File file = new File("test.txt");    
      // Créer l'objet File Reader
      FileReader fr = new FileReader(file);  
      // Créer l'objet BufferedReader        
      BufferedReader br = new BufferedReader(fr);  
      StringBuffer sb = new StringBuffer();    
      String line;
      while((line = br.readLine()) != null)
      {
        // ajoute la ligne au buffer
        mots.add(line);      
       // mots.add("\n");     
      }
      fr.close();   
     
    }
    catch(IOException e)
    {
      e.printStackTrace();
    }
  }

public String toString(int nbre1) {
    
	return "" + mots.get(nbre1) + "";
}

 
  
}
