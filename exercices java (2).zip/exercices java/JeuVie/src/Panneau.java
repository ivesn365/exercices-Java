import java.awt.*;
import javax.swing.JPanel;
public class Panneau extends JPanel{
	
	public void paintComponent(Graphics g){
		Graphics2D g2d = (Graphics2D)g;
		GradientPaint gp = new GradientPaint(20, 20,
		Color.yellow, 95, 95, Color.blue, true);
		g2d.setPaint(gp);
		g2d.fillOval(this.getWidth()/4, this.getHeight()/4,this.getWidth()/2, this.getHeight()/2);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Panneau p = new Panneau();

	}

}
