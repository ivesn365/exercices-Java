package POO;

/*
 * Est une classe de cargaison AerienneUrgente
 * cette classe hérite de la classe cargaison
 */

public class Car_AerienneUrgente extends Cargaison{
	
	public Car_AerienneUrgente() {
		super();
		// Constructreur par défaut
	}

	public Car_AerienneUrgente(int volume, int poids, int distance) {
		super(volume, poids, distance);
		// Constructreur initialisant
	}

	public void ajouter() { // permet d’ajouter une marchandise dans cette cargaison si le poid de la marchanddise <= 80000.
		if(this.volume <= 80000) {
			System.out.println("Votre marchandise a été ajouter avec succès dans la cargaison AerienneUrgente! et le coût est de : "+cout()+" euro");
		}else
			System.out.println("Impossible d'ajouter la marchandise, son poids > 800000 !");
	}
	
	public int cout() { // permet de retourner, sous la forme d’un nombre entier d’euros, le coût total du transport de cette cargaison.
		return 2 * (this.volume * this.distance * 10);
	}

}
