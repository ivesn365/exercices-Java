package POO;
/*
 * Est une classe de cargaison Fluviale
 * cette classe hérite de la classe cargaison
 */
public class Car_Fluviale extends Cargaison {

	public Car_Fluviale() {
		super();
		// Constructreur par défaut 
	}

	public Car_Fluviale(int volume, int poids, int distance) {
		super(volume, poids, distance);
		// Constructreur initialisant 
	}
	
	

}
