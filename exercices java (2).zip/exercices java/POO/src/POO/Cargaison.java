package POO;
/*
 * Est une classe de Cargaison
 * Une cargaison est par ailleurs également caractérisée par la distance sur laquelle elle est transportée 
 * une cargaison dépend d’un encombrement total de ces marchandises à ne pas dépasser. 
 * Cet encombrement est soit le poids total, soit le volume total selon le type de cargaison utilisée
 
 */

public class Cargaison extends Marchandise{
	protected int distance;

	public Cargaison() {
		super();
		// Constructreur par défaut
	}

	public Cargaison(int volume, int poids, int distance) {
		super(volume, poids);
		// Constructreur initialisant 
		
		this.distance = distance;
	}


	public void ajouter() { // permet d’ajouter une marchandise dans cette cargaison si le poid de la marchanddise <= 30000.
		if(this.poids <= 30000) {
			System.out.println("Votre marchandise a été ajouter avec succès dans la cargaison! et le coût est de : "+cout()+" euro");
		} else
			System.out.println("Impossible d'ajouter la marchandise, son poids > 300000 !");
	}
	
	public int cout() { // permet de retourner, sous la forme d’un nombre entier d’euros, le coût total du transport de cette cargaison.
		return this.poids * this.distance;
	}
	
	
}
