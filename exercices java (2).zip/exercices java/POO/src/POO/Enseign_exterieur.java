package POO;

public class Enseign_exterieur extends Enseignant {
	//Classe représentant un enseignant visiteur. Elle hérite de la classe Enseignant

	public Enseign_exterieur() {
		super();
		// Constructeur par defaut de notre classe
	}

	public Enseign_exterieur(String nom, int nbreHeureTotal) {
		super(nom, nbreHeureTotal);
		// Constructeur reinitialisant  par defaut de notre classe
	}

	public int hc() {
		return nbreHeureTotal;
	}
	
	public int retribution() {
		return hc() * 35;
	}

}
