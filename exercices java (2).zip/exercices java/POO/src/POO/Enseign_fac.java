package POO;

public class Enseign_fac extends Enseignant{
	// Classe représentant un enseignant permanant. Elle hérite de la classe Enseignant

	public Enseign_fac() {
		// Constructeur par defaut de notre classe
		super();
		// TODO Auto-generated constructor stub
	}

	public Enseign_fac(String nom, int nbreHeureTotal) {
		super(nom, nbreHeureTotal);
		// Constructeur reinitialisant de notre classe"
	}

	

}
