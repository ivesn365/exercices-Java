package POO;

public class Enseignant {
	/*
	 * Classe représentant un enseignant
	 * Nom de l'enseignant
	 *Nombre d'heure totale */
	private String nom;
	protected int nbreHeureTotal;
	public Enseignant() { 
		super();
		// Le constructeur par défaut
	}
	public Enseignant(String nom, int nbreHeureTotal) { //  Le construteur initilisant
		super();
		this.nom = nom;
		this.nbreHeureTotal = nbreHeureTotal;
	}
	
	public String nom() { // Cette méthode retourne le nom de l'enseignant 
		return "Le nom de l'enseignant est : "+nom;
	}
	
	public int hc() {// Cette méthode retourne les heures complementaire de l'enseignant
		return nbreHeureTotal - 192;
	}
	
	public int retribution() {
		return hc() * 35;
	}
}