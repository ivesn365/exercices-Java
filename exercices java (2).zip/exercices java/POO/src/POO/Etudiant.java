package POO;

public class Etudiant extends Personnes implements MonInterface{

	public Etudiant() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Etudiant(String nom, String adresse, int numero, String promotion) {
		super();
		// TODO Auto-generated constructor stub
		this.nom = nom;
		this.adresse = adresse;
		this.numero = numero;
		this.promotion = promotion;
	}
	public String getNom() { return this.nom; }
	public void setNom(String nom) {this.nom = nom; }
	public String getAdresse() {return this.adresse;}
	public void setAdresse(String adresse) {this.adresse = adresse;}
	public int getNumero() {return this.numero;}

	@Override
	public void afficher() {
		// Cette methode affiche les information de l'etudiant
		System.out.println("nom : "+this.nom +", l'adresse : "+ this.adresse +"et le numéro : "+ this.numero);		
	}



	@Override
	public String  profilEtudiant() {
		// Cette methode retourne le profil d'un etudiant
		return "Je suis un etudiant de licence, ici on parle de parcours";
		
	}
	@Override
	public String toString() {
		return "Etudiant [nom=" + nom + ", adresse=" + adresse + ", numero=" + numero + ", promotion=" + promotion + "]";
	}

	
	

}
