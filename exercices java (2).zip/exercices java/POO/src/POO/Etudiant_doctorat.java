package POO;

public class Etudiant_doctorat extends Etudiant{
	
	public Etudiant_doctorat() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Etudiant_doctorat(String nom, String adresse, int numero, String promotion) {
		super(nom, adresse, numero, promotion);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void afficher() {
		// Cette methode affiche les information de l'etudiant
		System.out.println("nom : "+this.nom +", l'adresse : "+ this.adresse +"et le numéro : "+ this.numero + "son profil est :"+ profilEtudiant());		
	}

	@Override
	public String profilEtudiant() {
		// Cette methode retourne le profil d'un etudiant
		return "Je suis un etudiant de doctorat, ici on parle de la recherche! ! !";
		
	}


}
