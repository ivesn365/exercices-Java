package POO;

public class Etudiant_lience extends Etudiant {

	public Etudiant_lience() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Etudiant_lience(String nom, String adresse, int numero, String promotion) {
		super(nom, adresse, numero,  promotion);
		// TODO Auto-generated constructor stub
	}
	
  

}
