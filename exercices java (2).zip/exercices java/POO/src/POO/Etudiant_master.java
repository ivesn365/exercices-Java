package POO;

public class Etudiant_master extends Etudiant{
	
	public Etudiant_master() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Etudiant_master(String nom, String adresse, int numero, String promotion) {
		super(nom, adresse, numero, promotion);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void afficher() {
		// Cette methode affiche les information de l'etudiant
		System.out.println("nom : "+this.nom +", l'adresse : "+ this.adresse +"et le numéro : "+ this.numero + "son profil est :"+ profilEtudiant());		
	}

	@Override
	public String  profilEtudiant() {
		// Cette methode retourne le profil d'un etudiant
		return "Je suis un etudiant de Master, ici on parle de la spécialisation ! ! !";
		
	}

}
