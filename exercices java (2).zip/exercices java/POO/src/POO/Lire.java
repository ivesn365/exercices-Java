package POO;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.LinkedList;
import java.util.List;


public class Lire {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nomComplet = "";
		String adresse = "";
		int numero = 0;
		String promotion = "";
		int reponse = 1;
		List<Etudiant> maListe = new ArrayList<Etudiant>();
		Scanner sc = new Scanner(System.in);
		System.out.println("======================================================================================================");
		System.out.println("-------------------------------Bienvenue dans votre application ! ! !--------------------------------");
		System.out.println("======================================================================================================");
		do {
			System.out.println("Taper le nom Complet d'un étudiant :");
			nomComplet = sc.nextLine();
			System.out.println("Taper l'adresse d'un étudiant :");
			adresse = sc.nextLine();
			System.out.println("Taper le numéro d'un étudiant");
			numero = sc.nextInt();
			System.out.println("Taper la promotion d'un étudiant");
			promotion = sc.nextLine();
			maListe.add(new Etudiant(nomComplet, adresse, numero, promotion));
			System.out.println("Voulez-vous continuer?(1/0) :");
			reponse = sc.nextInt();
		}while(reponse == 1);
		
		
		for(int i = 0; i < maListe.size(); i++) System.out.println(maListe.get(i));
		
		
		

	}

}
