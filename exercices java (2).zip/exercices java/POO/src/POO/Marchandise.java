package POO;

public class Marchandise {
	protected  int volume;
	protected int poids;
	public Marchandise() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Marchandise(int volume, int poids) {
		super();
		this.volume = volume;
		this.poids = poids;
	}
	public int poids() {// retourne le poids
		return this.poids;
	}
	
	public int volume() {// retourne le volume
		return this.volume;
	}

}
