package POO;

public interface MonInterface {
	abstract void afficher();
	abstract String profilEtudiant();
	abstract String toString();

}
