package POO;

public abstract class Personnes {
	protected String nom;
	protected String adresse;
	protected int numero;
	protected String promotion;

	
		
}
