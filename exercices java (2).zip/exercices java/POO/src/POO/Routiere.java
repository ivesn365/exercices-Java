package POO;

/*
 * Est une classe de cargaison Routiere
 * cette classe hérite de la classe cargaison
 */

public class Routiere extends Cargaison{
	
	
	public Routiere() {
		super();
		// Constructreur par défaut
	}

	public Routiere(int volume, int poids, int distance) {
		super(volume, poids, distance);
		// Constructreur initialisant
	}

	public void ajouter() { // permet d’ajouter une marchandise dans cette cargaison si le poid de la marchanddise <= 38000.
		if(this.poids <= 38000) {
			System.out.println("Votre marchandise a été ajouter avec succès dans la cargaison Routière! et le coût est de : "+cout()+" euro");
		}else
			System.out.println("Impossible d'ajouter la marchandise, son poids > 380000 !");
	}
	
	public int cout() { // permet de retourner, sous la forme d’un nombre entier d’euros, le coût total du transport de cette cargaison.
		return this.poids * this.distance * 4;
	}


}
