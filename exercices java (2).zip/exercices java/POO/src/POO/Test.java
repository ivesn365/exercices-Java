package POO;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Marchandise marchandise = new Marchandise(10, 54);
		System.out.println("Le poids de la marchandise est : "+ marchandise.poids());
		System.out.println("Le volume de la marchandise est : "+ marchandise.volume());
		Cargaison car = new Cargaison(10, 54, 85);
		Car_Fluviale car_Fl = new Car_Fluviale(10, 54, 85);// Cargaison Fluviale
		car_Fl.ajouter();
		Routiere car_R = new Routiere(10, 54, 85);// Cargaison Routière
		car_R.ajouter();
		Car_Aerienne car_A = new Car_Aerienne(10, 54, 85);// Cargaison Aerienne
		car_A.ajouter();
		Car_AerienneUrgente car_Au = new Car_AerienneUrgente(10, 54, 85);// Cargaison AerienneUrgente
		car_Au.ajouter();
		

	}

}
