package POO;

public class enseign_Etudiant extends Enseignant{
	/*Classe représentant un etudiant */

	public enseign_Etudiant() {
		super();
		// TODO Auto-generated constructor stub
	}

	public enseign_Etudiant(String nom, int nbreHeureTotal) {
		super(nom, nbreHeureTotal);
		// TODO Auto-generated constructor stub
	}

	public int hc() {
		return nbreHeureTotal - 92;
	}

}
