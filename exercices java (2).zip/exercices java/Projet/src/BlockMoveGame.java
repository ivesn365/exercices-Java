import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class BlockMoveGame extends JFrame
{
	final int RC = 4;	// ÐÐÁÐÊý
	final int N = RC*RC;	// ¿éµÄžöÊý
	//Êý×énumÓÃÓÚŒÇÂŒÃ¿žö°ŽÅ¥ÉÏµÄÊý×Ö-1
	int []num = new int[N];   
	JButton [] btn = new JButton[N];
	JButton btnStart = new JButton("¿ªÊŒÓÎÏ·");

	public BlockMoveGame(){
		setTitle( "Œòµ¥µÄÅÅ¿éÓÎÏ·");
		setSize( 300, 350 );
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		//³ÌÐò¿ªÊŒ,¶ÔÊý×éž³Öµ,²¢ÏÔÊŸ°ŽÅ¥ÎÄ×Ö
		JPanel pnlBody = new JPanel();
		JPanel pnlFoot = new JPanel();
		pnlBody.setLayout( new GridLayout( RC, RC ));
		pnlFoot.add( btnStart );
		getContentPane().setLayout( new BorderLayout() );
		getContentPane().add(pnlBody, BorderLayout.CENTER );
		getContentPane().add(pnlFoot, BorderLayout.SOUTH );

		Font font = new Font("Times New Rome", 0, 24 );
		for( int i=0; i<N; i++ ){
			num[i] = i;
			btn[i] = new JButton(""+ ( num[i] + 1 ));
			btn[i].setFont(font);
			pnlBody.add(btn[i]);
			btn[i].setVisible( true );
		}
		btn[N-1].setVisible( false ); //Êý×ÖÎªN-1µÄ°ŽÅ¥²»ÏÔÊŸ

		btnStart.addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent e){
				btnStart_Click();
			}
		});
		for( int i=0; i<N; i++ ){
			btn[i].addActionListener( new ActionListener(){
				public void actionPerformed( ActionEvent e){
					for( int j=0; j<N; j++ )
						if( (JButton)e.getSource() == btn[j] )
							btn_Click(j);
				}
			});
		}
	}

	public void btnStart_Click(){
		//ŽòÂÒË³Ðò£¬¿ªÊŒÓÎÏ·
		//Ëæ»úÕÒÁœžöÏÂ±ê,œ»»»Æä¶ÔÓŠµÄÊý×éÔªËØ
		for( int i = 1; i<500; i++){ 
			int j = (int)(Math.random()* N);  
			int k = (int)(Math.random()* N);
			int t = num[j]; num[j] = num[k]; num[k] = t;
		}
		
		for( int i=0; i<N; i++ ){//ÏÔÊŸËüÃÇ
			btn[i].setText(""+ (num[i] + 1));
			btn[i].setVisible( true );
		}
		int blank = findBlank();  //ÆäÖÐÓÐÒ»žö°ŽÅ¥ÐèÒªÒþ²Ø
		btn[blank].setVisible(false);
	}

	//ÕÒµœÄÄÒ»žöÎª¿ÕÎ»
	int findBlank(){  
		for(int i=0; i<N; i++ ){ 
			if( num[i] == N-1 ) return i; 
		}
		return -1; 
	}

	//µÚIndexžö°ŽÅ¥µÄÊÂŒþŽŠÀí
	void btn_Click(int index){  
		int blank = findBlank();           //ÕÒµœ¿Õ°×°ŽÅ¥(Òþ²ØµÄ)
		if( isNeighbor(blank, index)){       //Èç¹ûÏàÁÚ
			btn[index].setVisible( false );  //Ò»žöÒþ²Ø,Ò»žöÏÔÊŸ
			btn[blank].setVisible( true );   //²¢œ»»»ÆäÉÏµÄÊý×Ö
			int t = num[blank]; 
			num[blank] = num[index]; 
			num[index] = t;
			btn[blank].setText( ""+ (num[blank] + 1));
			btn[index].setText( ""+ (num[index] + 1));
			btn[blank].requestFocus();  //œ¹µãÒÆµœÔ­°ŽÅ¥ÉÏ£¬ÒÔÈÃÓÃ»§¿ŽÇå
		}
		checkResult();  //µ÷ÓÃ¹ý³Ì,Œì²éÊÇ·ñÍê³É
	}

	//ÅÐ¶ÏÊÇ·ñÏàÁÚ
	boolean isNeighbor(int a, int b){  
		boolean r = false;
		if( a == b - RC || a == b + RC ) 
			r = true;  //ÉÏÏÂÏàÁÚ
		if( (a == b - 1 || a == b + 1) && a / RC == b / RC ) 
			r = true; //×óÓÒÏàÁÚ,×¢ÒâÒªÔÚÍ¬Ò»ÅÅ
		return r;
	}
	//Œì²éœá¹ûÊÇ·ñÍêÈ«µœÎ»
	void checkResult(){  
		for(int i=0; i<N; i++ ){     
			if( num[i] != i ) return; 
		}
		JOptionPane.showMessageDialog(this,
			"ÄãÓ®ÁË!Çëµã»÷ [¿ªÊŒ] ÔÙÀŽÒ»ŽÎ.");
	}

	public static void main(String... args) {
		SwingUtilities.invokeLater(()->{
			new BlockMoveGame().setVisible(true);
		});
    }
}

