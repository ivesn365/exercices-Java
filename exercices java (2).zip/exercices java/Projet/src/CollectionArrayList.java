import java.util.ArrayList;
import java.util.ListIterator;

public class CollectionArrayList {

	public static void main(String[] args) {
		// Est un de ces objets qui n'ont pas de taille limite et qui n'ont pas de taille limite et qui en plus acceptent n'importe quel type de données, y compris null
		ArrayList al = new ArrayList();
		al.add(12);
		al.add("une chaine de caractere ! ! !");
		al.add(12.02f);
		al.add('d');
		
		for(int i = 0; i < al.size(); i++)
			System.out.println("Element à l'index : "+ i +" = "+ al.get(i));
		System.out.println("\t-----------------------------Parcours avec un iterateur --------------------------------");
        // un iterateur est un objet qui a pour rôle de parcourir une collection.
		ListIterator li = al.listIterator();
		while(li.hasNext())
			System.out.println(li.next());

	}

}
