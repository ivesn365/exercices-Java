import java.util.LinkedList;

import java.util.List;
import java.util.ListIterator;

public class CollectionLinkedList {

	public static void main(String[] args) {
		// Une liste chainée est une liste dont chaque élément est lié aux éléments adjacents par une 
		// Reference à ces derniers
		
		List l = new LinkedList();
		l.add(12);
		l.add(12.2f);
		l.add("Toto ! ! !");
		
		for(int i = 0; i < l.size(); i++)
			System.out.println("Element à l'index : "+ i +" = "+ l.get(i));
		
		System.out.println("\t-----------------------------Parcours avec un iterateur --------------------------------");
          // un iterateur est un objet qui a pour rôle de parcourir une collection.
		
		ListIterator li = l.listIterator();
		while(li.hasNext())
			System.out.println(li.next());
	}

}
