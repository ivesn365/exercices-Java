import java.util.Enumeration;
import java.util.Hashtable;

public class CollectionMapHashtable {
	public static void main(String[] args) {
		//Une collection Map est une collection qui fonctionne  avec un couple clé-valeur 
		// il n'accepte pas la valeur null
		Hashtable ht = new Hashtable();
		ht.put(1, "printemps");
		ht.put(10, "été");
		ht.put(12, "automne");
		ht.put(45, "hiver");
		
		Enumeration e = ht.elements();
		
		while(e.hasMoreElements())
			System.out.println(e.nextElement());
	}


}
