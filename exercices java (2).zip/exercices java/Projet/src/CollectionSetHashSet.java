import java.util.HashSet;
import java.util.Iterator;

public class CollectionSetHashSet {

	public static void main(String[] args) {
		// un set est une collection qui n'acceptent pas les doublons
		
		HashSet hs = new HashSet();
		hs.add("toto");
		hs.add(1);
		hs.add(12);
		hs.add('d');
		hs.add('c');
		
		Iterator it = hs.iterator();
		
		while(it.hasNext())
			System.out.println(it.next());

	}

}
