/* It is an interface that is composed of the following methods:
 *afficherNom()
 *afficherAdress()
 *toString() */
public interface Ecole {
	void afficherNom();
	void afficherAdress();
	String toString();

}
