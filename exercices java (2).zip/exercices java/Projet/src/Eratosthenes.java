public class Eratosthenes {

    int[] removeMultipleOfBase(int base, int[] a) {
        if (base > a[a.length - 1])
            return a;

        int end = 0;

        // 找出base的index
        for (int i = 0; i < a.length; i++) {
            if (a[i] == base)
                end = i;
        }

        // 去掉base的倍数们
        for (int i = end + 1; i < a.length; i++) {
            if (a[i] > a[end] && a[i] % base != 0) {
                end++;
                a[end] = a[i];
            }
        }

        int[] arrayAfterRemove = trimArray(0, end, a);

        return arrayAfterRemove;
    }

    int[] trimArray(int indexStart, int indexEnd, int[] a) {
        int length = indexEnd - indexStart + 1;

        int[] partA = new int[length];

        for (int i = 0; i < length; i++) {
            partA[i] = a[indexStart + i];
        }

        return partA;
    }

    int[] findPrimes(int[] a) {
        int sqrtNum = (int)Math.sqrt(a[a.length - 1]);

        int[] basePrimes = {2, 3, 5, 7};

        int[] array = a.clone();

        if (sqrtNum <= 10) {
            for (int basePrime : basePrimes) {
                array = removeMultipleOfBase(basePrime, array);
            }
        }
        else  {
            // 若数组不止2～100，先截短，再处理
            int[] sqrtArray = trimArray(0, sqrtNum, a);
            int[] primesInSqrtArray = findPrimes(sqrtArray);

            for (int p : primesInSqrtArray) {
                array = removeMultipleOfBase(p, array);
            }
        }

        return array;
    }

    public static void main(String[] args) {
        int n = 10000;
        int[] a = new int[n - 1];

        for (int i = 0; i < n - 1; i++)
            a[i] = 2 + i;

        int[] primes = new Eratosthenes().findPrimes(a);

        for (int prime : primes) {
            System.out.print(prime + " ");
        }
    }


}
