/* Herite student class personne and the interface */
public class Etudiant extends Personne implements Ecole{
	protected String matricule;
	protected String promotion;

	public Etudiant(String nom, String postnom, String prenom, int age, String adresse, String matricule, String promotion) {
		// initiazation constructor
		this.matricule = matricule;
		this.promotion = promotion;
		this.nom = nom;
		this.postnom = postnom;
		this.prenom = prenom;
		this.age = age;
		this.adresse = adresse;
	}

	public String getMatricule() {
		return matricule;
	}

	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}

	public String getPromotion() {
		return promotion;
	}

	public void setPromotion(String promotion) {
		this.promotion = promotion;
	}

	@Override
	public String toString() {
		// returns all student information
		return "Etudiant [Nom : "+this.nom + ", Postnom : "+ this.postnom+", Prenom : "+this.prenom+", matricule :" + matricule + ", promotion : " + promotion + "]";
	}
	
	@Override
	public void afficherNom() {
		// This method displays the name of the student
		System.out.println("Le nom complet de l'étudiant : "+this.nom+", Postnom : "+this.postnom+",Prenom : "+this.prenom);
	}
	
	@Override
	public void afficherAdress() {
		//This method displays the student's address
		System.out.println("L'adresse de l'étudiant est : "+this.adresse);
		
	}
	

}
