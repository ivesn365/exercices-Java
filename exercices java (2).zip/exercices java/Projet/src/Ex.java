
public class Ex extends Thread{
	Ex(String name){
		super(name);
	}
	public void run() {
		for(int i = 0; i < 10; i++)System.out.println(this.getName());
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex t = new Ex("H");
		Ex t2 = new Ex(" k");
		t.start();
		t2.start();
		
	}

}
