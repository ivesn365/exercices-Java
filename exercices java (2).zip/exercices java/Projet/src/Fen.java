

import java.awt.*;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Fen extends JFrame{
	//JFrame fen = new JFrame();
	JButton[] btn = new JButton[8];
	
	public Fen() {
		for(int i = 0;i < btn.length; i++)btn[i] = new JButton("Btn" +(i+1));
		setLayout(new GridLayout(4, 5));
		
		for(int i = 0; i < btn.length; i++) add(btn[i]);
		setSize(300, 200);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	public static void main(String[] arg) {
		Fen t = new Fen();
	}
	

}

