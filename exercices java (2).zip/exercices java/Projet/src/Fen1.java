import java.awt.BorderLayout;
import java.awt.Button;

import javax.swing.*;

public class Fen1 extends JFrame{
	Fen1(){
		setLayout(new BorderLayout());
		add(new Button("NORTH"), BorderLayout.NORTH);
		add(new Button("SOUTH"), BorderLayout.SOUTH);
		add(new Button("EAST"), BorderLayout.EAST);
		add(new Button("CENTER"), BorderLayout.CENTER);
		add(new Button("NORTH"), BorderLayout.NORTH);
		
		setSize(300, 200);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		
	}
	
	public static void main(String[] arg) {
		Fen1 t = new Fen1();
	}
	
	
}