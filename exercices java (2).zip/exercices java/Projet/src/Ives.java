import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Ives {
	JFrame fen = new JFrame();
	JButton[] btn = new JButton[8];
	
	public Ives() {
		for(int i = 0;i < btn.length; i++)btn[i] = new JButton("Btn" +(i+1));
		fen.setLayout(new BorderLayout());
		
		for(int i = 0; i < btn.length; i++) fen.add(btn[i]);
		fen.setSize(300, 200);
		fen.setDefaultCloseOperation(EXIT_ON_CLOSE);
		fen.setVisible(true);
	}
	
	static void main(String[] arg) {
		Ives t = new Ives();
	}
	

}
