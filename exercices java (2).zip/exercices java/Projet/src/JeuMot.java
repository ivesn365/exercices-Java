import java.util.ArrayList;
import java.util.regex.*;
import java.util.List;

public class JeuMot {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		mot();
		
		

	}
	public static void mot() {
		Pattern p;
		Matcher m;
		List<String> maListe = new ArrayList<String>();
		List<String> sign = new ArrayList<String>();
		sign.add("Ives, c'est une personne morale");
		sign.add("Laure, c'est une personne morale du genre feminin ! ! !");
		sign.add("Dina, c'est une personne morale du genre feminin ! ! !");
		maListe.add("Ives");
		maListe.add("Laure");
		maListe.add("Dina");
		for(String mots : maListe) {
			p = Pattern.compile(mots);
			for(String s : sign) {
				m = p.matcher(s);
				if(m.find())System.out.println(mots + " : "+ s);
			}
		}
			
			
	

}
	}
