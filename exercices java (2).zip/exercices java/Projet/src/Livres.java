import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Livres{
	
	List<String> maListe = new ArrayList<String>();
	List<String> sign = new ArrayList<String>();
	Livres(){
		maListe.add("Ives");
		maListe.add("Laure");
		maListe.add("Dina");
		maListe.add("Marie");
		sign.add("Ives, c'est une personne morale");
		sign.add("Laure, c'est une personne morale du genre feminin ! ! !");
		sign.add("Dina, c'est une personne morale du genre feminin ! ! !");
		
	}
	Livres(String mot, String signi){
		maListe.add(mot);
		sign.add(signi);
	}
	

	public List<String> getMaListe() {
		return maListe();
	}

	public List<String> maListe() {
		maListe.add("Ives");
		maListe.add("Laure");
		maListe.add("Dina");
		maListe.add("Marie");
		return maListe;
	}

	public List<String> getSign() {
		return sign;
	}

	public  List<String> sign() {
		sign.add("Ives, c'est une personne morale");
		sign.add("Laure, c'est une personne morale du genre feminin ! ! !");
		sign.add("Dina, c'est une personne morale du genre feminin ! ! !");
		return sign;
	}
	
	void setMaListe(String mots, String signe) {
		maListe.add(mots);
		sign.add(signe);
	}

	
}
