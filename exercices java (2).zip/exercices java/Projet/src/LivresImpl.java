import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.*;

import java.util.Scanner;
import java.util.concurrent.*;

public class LivresImpl  implements Runnable{
	private Livres livre = new Livres();
	Pattern p;
	Matcher m;
	int i = 1, reponse = 1;
	Scanner sc = new Scanner(System.in);
	String mot, signe;

	public LivresImpl() {
		super();
		this.livre = livre;
		System.out.println("==========================Bienvenue dans ton livre numérique==============================\n"
				+ "======================Voici les mots qui sont dans ton livre========================");
		/**/
		
	}
	
	
	public void run() {
		try {
		for(String mots : livre.maListe) {
			p = Pattern.compile(mots);
			
			for(String s : livre.sign) {
				m = p.matcher(s);
				
				if(m.find())
					{
					 Thread.sleep((int)(Math.random()*10));
					 System.out.println(i + "."+ mots + ": "+ s);
					}
				
			 }
			i++;
			
		}
		do{
			 System.out.println("Voulez-vous ajouter un mot à votre livre?: ");
			 System.out.println("Ajoutez le mots");
			 mot = sc.nextLine();
			 System.out.println("Ajoutez la signification de ton mot :");
			 signe = sc.nextLine();
			 run(mot, signe);
			 //System.out.println(" ");
			 
			 System.out.println("Voulez-vous continuer? 1/0");
			 reponse =  sc.nextInt();
			 
			 
		 }while(reponse != 0);
	 
		 
	}catch(InterruptedException e) {}
	}
	
	
	
	
	public void run(String mots, String signe) {
		livre =  new Livres(mots, signe);
		run();
	}
	

}
