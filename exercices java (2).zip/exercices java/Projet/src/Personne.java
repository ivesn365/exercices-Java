
public abstract  class Personne implements Ecole{
	protected String nom;
	protected String postnom;
	protected String prenom;
	protected int age;
	protected String adresse;
		

}
