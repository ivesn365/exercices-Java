
public class PrincipalClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("\n---------------------------------student of the college---------------------------------------");
		Etudiant etudiant = new Etudiant("Ngalae", "Nyunga", "Ies", 25, "Lubumbashi", "17NN", "kcccc");
		Etudiant etudiant2 = new Etudiant("Lukadi", "nga", "Laure", 35, "Kinshasa", "16LN", "kjjddc");
		Etudiant etudiant3 = new Etudiant("Mbombo", "Kanku", "Romu", 60, "Lubumbashi", "18MK", "kcccc");
		Etudiant etudiant4 = new Etudiant("JOjo", "jk", "patrick", 25, "Lubumbashi", "17jN", "kcccc");
		Etudiant etudiant5 = new Etudiant("kiki", "Nyunga", "Ives", 25, "Lubumbashi", "17kN", "kcccc");
		Etudiant etudiant6 = new Etudiant("Vadam", "gogo", "popos", 25, "Lubumbashi", "19VG", "kcccc");
		Etudiant etudiant7 = new Etudiant("Lulu", "jk", "liuuy", 29, "Lubumbashi", "17LJ", "kcccc");
		Etudiant etudiant8 = new Etudiant("Ngalamulume", "Nyunga", "Ives", 25, "Lubumbashi", "17NN", "kcccc");
		Etudiant etudiant9 = new Etudiant("Ngala", "Nbombo", "Tina", 25, "Lubumbashi", "17NN", "kcccc");
		Etudiant etudiant10 = new Etudiant("Gedeon", "ilunga", "Ives", 25, "Lubumbashi", "17NN", "kcccc");
		
		System.out.println(etudiant.toString());
		etudiant.afficherNom();
		etudiant.afficherAdress();
		System.out.println(etudiant2.toString());
		etudiant2.afficherNom();
		etudiant2.afficherAdress();
		System.out.println(etudiant3.toString());
		etudiant3.afficherNom();
		etudiant3.afficherAdress();
		System.out.println(etudiant4.toString());
		etudiant4.afficherNom();
		etudiant4.afficherAdress();
		System.out.println(etudiant5.toString());
		etudiant5.afficherNom();
		etudiant5.afficherAdress();
		System.out.println(etudiant6.toString());
		etudiant6.afficherNom();
		etudiant6.afficherAdress();
		System.out.println(etudiant7.toString());
		etudiant7.afficherNom();
		etudiant7.afficherAdress();
		System.out.println(etudiant8.toString());
		etudiant8.afficherNom();
		etudiant8.afficherAdress();
		System.out.println(etudiant9.toString());
		etudiant9.afficherNom();
		etudiant9.afficherAdress();
		System.out.println(etudiant10.toString());
		etudiant10.afficherNom();
		etudiant10.afficherAdress();
		System.out.println("\n---------------------------------Visitor teacher---------------------------------------");
		Professeur Prof = new Professeur("Danr", "JeanLOUIS", "Jacque", 85, "Paris", 58, "kcccc");
		Professeur Prof2 = new Professeur("Juju", "yan", "JUJU", 50, "Pekin", 20, "kcccc");
		Professeur Prof3 = new Professeur("RogerLouis", "JeanMarc", "Ives", 55, "Lubumbashi", 12, "kcccc");
		Professeur Prof4 = new Professeur("Van", "Van", "Jac", 53, "Bangui", 10, "kcccc");
		Professeur Prof5 = new Professeur("Roger", "Jean", "Jacque", 55, "Lubumbashi", 58, "kcccc");
		System.out.println(Prof.toString());
		Prof.afficherNom();
		Prof.afficherAdress();
		System.out.println(Prof2.toString());
		Prof3.afficherNom();
		Prof3.afficherAdress();
		System.out.println(Prof3.toString());
		Prof3.afficherNom();
		Prof3.afficherAdress();
		System.out.println(Prof4.toString());
		Prof4.afficherNom();
		Prof4.afficherAdress();
		System.out.println(Prof5.toString());
		Prof5.afficherNom();
		Prof5.afficherAdress();
		System.out.println("\n---------------------------------teacher of the college---------------------------------------");
		ProfesseurFac profFc = new ProfesseurFac("Danr", "JeanLOUIS", "Jacque", 85, "Paris", 58, "kcccc", "admin");
		ProfesseurFac profFc2 = new ProfesseurFac("Juju", "yan", "JUJU", 50, "Pekin", 20, "kcccc", "coord");
		ProfesseurFac profFc3 = new ProfesseurFac("RogerLouis", "JeanMarc", "Ives", 55, "Lubumbashi", 12, "kcccc", "coord");
		ProfesseurFac profFc4 = new ProfesseurFac("Roger", "Jean", "Jacque", 55, "Lubumbashi", 58, "kcccc", "admin");
		System.out.println(profFc.toString());
		profFc.afficherNom();
		profFc.afficherAdress();
		System.out.println(profFc2.toString());
		profFc2.afficherNom();
		profFc3.afficherAdress();
		
		System.out.println(profFc4.toString());
		profFc4.afficherNom();
		profFc4.afficherAdress();
		
		
		
		

	}

}
