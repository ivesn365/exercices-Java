/* Class of the visitor teacher 
 * Class Professeur  hertite class Personne
 *  and interface Ecole */
public class Professeur extends Personne implements Ecole {
	protected int heureComplementaire;// Complementary time
	protected String nomCours;

	public Professeur(String nom, String postnom, String prenom, int age, String adresse, int heureComplementaire, String nomCours) {
		// initiazation constructor
		this.heureComplementaire = heureComplementaire;
		this.nomCours = nomCours;
		this.nom = nom;
		this.postnom = postnom;
		this.prenom = prenom;
		this.age = age;
		this.adresse = adresse;
	}

	public int getHeureComplementaire() {
		return heureComplementaire;
	}

	public void setHeureComplementaire(int heureComplementaire) {
		this.heureComplementaire = heureComplementaire;
	}

	public String getNomCours() {
		return nomCours;
	}

	public void setNomCours(String nomCours) {
		this.nomCours = nomCours;
	}
	@Override
	public String toString() {
		// return all the information from the visitor teacher
		return "Professeur [Nom : "+this.nom + ", Postnom : "+ this.postnom+", Prenom : "+this.prenom+", eureComplementaire :" + heureComplementaire+ ", Nom du cours : " + nomCours + "]";
	}
	
	@Override
	public void afficherNom() {
		// This method displays the full name of the visitor teacher
		System.out.println("Le nom complet du professeur : "+this.nom+", Postnom : "+this.postnom+",Prenom : "+this.prenom);
	}
	
	@Override
	public void afficherAdress() {
		// This method shows the address of the visitor teacher
		System.out.println("L'adresse du professeur est : "+this.adresse);
		
	}
	


}
