/* Class of the teacher of the Faculty 
 * Class ProfesseurFac herite class Professeur */
public class ProfesseurFac extends Professeur{
	protected String role;

	public ProfesseurFac(String nom, String postnom, String prenom, int age, String adresse, int heureComplementaire,
			String nomCours, String role) {
		super(nom, postnom, prenom, age, adresse, heureComplementaire, nomCours);
		// initiazation constructor
		this.role = role;
	}
	
	
	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	@Override
	public String toString() {
		// Returns all the information from the teacher of the Faculty
		return "Faculty Professor [Nom : "+this.nom + ", Postnom : "+ this.postnom+", Prenom : "+this.prenom+", eureComplementaire :" + heureComplementaire+ ", Nom du cours : " + nomCours + "]";
	}
	
	@Override
	public void afficherNom() {
		// This method displays the full name of the teacher
		System.out.println("Le nom complet du professeur de Faculte: "+this.nom+", Postnom : "+this.postnom+",Prenom : "+this.prenom);
	}
	
	@Override
	public void afficherAdress() {
		// This method displays the teacher's adress
		System.out.println("L'adresse du professeur de Faculte est : "+this.adresse);
		
	}
	

}
