package Projet;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSplitPane;

public class Fenetre extends JFrame{
	//On déclare notre objet JSplitPane
	private JSplitPane split;
	
	//Vous êtes habitué à cette classe, maintenant
	
	public Fenetre() {
		this.setLocationRelativeTo(null);
		this.setTitle("Gérer vos conteneur");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(200, 200);
		
		JPanel pan = new JPanel();
		pan.setBackground(Color.blue);
		
		JPanel pan2 = new JPanel();
		pan2.setBackground(Color.red);
		
		//ON construit enfin notre separateur
		
		split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, pan, pan2);
		//ON le passe ensuite au contentPane de notre objet Fenetre
		//placé au centre pour qu'il utilise tout l'espace disponible
		this.getContentPane().add(split, BorderLayout.CENTER);
		
		this.setVisible(true);
	}
	
	public static void main(String[] args) {
		Fenetre fen = new Fenetre();
	}
}
