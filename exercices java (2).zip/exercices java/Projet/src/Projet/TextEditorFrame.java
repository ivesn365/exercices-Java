package Projet;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.logging.*;

class TextEditorFrame extends JFrame
{

	File file = null;
	Color color = Color.black;
	TextDAL dal = null;
	
	TextEditorFrame(TextDAL dal){
		this.dal = dal;

		initTextPane();
		initMenu();
		initAboutDialog();
		initToolBar();
	}

	void initTextPane(){ //œ«ÎÄ±Ÿ¿ò·ÅÈëÓÐ¹ö¶¯¶ÔÏó£¬²¢ŒÓÈëµœFrameÖÐ
		getContentPane().add( new JScrollPane(text) );
	}

	JTextPane text = new JTextPane();  //ÎÄ±Ÿ¿ò
	JFileChooser filechooser = new JFileChooser(); //ÎÄŒþÑ¡Ôñ¶Ô»°¿ò
	JColorChooser colorchooser = new JColorChooser(); //ÑÕÉ«Ñ¡Ôñ¶Ô»°¿ò
	JDialog about = new JDialog(this); //¹ØÓÚ¶Ô»°¿ò
	JMenuBar menubar = new JMenuBar(); //²Ëµ¥

	JMenu [] menus = new JMenu[] {
		new JMenu("File"),
		new JMenu("Edit"),
		new JMenu("Help")
	};
	JMenuItem menuitems [][] = new JMenuItem[][]{{
		new JMenuItem("New"), 
		new JMenuItem("Open..."),
		new JMenuItem("Save..."), 
		new JMenuItem("Exit")},{
		new JMenuItem("Copy"),
		new JMenuItem("Cut"),
		new JMenuItem("Paste"),
		new JMenuItem("Color...")},{
		new JMenuItem("About")}
	};

	void initMenu(){  //³õÊŒ»¯²Ëµ¥
		for( int i=0; i<menus.length; i++ ){
			menubar.add( menus[i] );
			for( int j=0; j<menuitems[i].length; j++ ){
				menus[i].add( menuitems[i][j] );
				menuitems[i][j].addActionListener( action );
			}
		}
		this.setJMenuBar( menubar );
	}

	ActionListener action = new ActionListener(){ //Classe anonime
		public void actionPerformed( ActionEvent e ){
			JMenuItem mi = (JMenuItem)e.getSource();
			String id = mi.getText();
			if( id.equals("New" )){
				text.setText("");
				file = null;
			}else if( id.equals("Open...")){
				if( file != null ) filechooser.setSelectedFile( file );
				int returnVal = filechooser.showOpenDialog(
					TextEditorFrame.this);
				if(returnVal == JFileChooser.APPROVE_OPTION) {
					file = filechooser.getSelectedFile();
					openFile();
				}
			}else if( id.equals("Save...")){
				if( file != null ) filechooser.setSelectedFile( file );
				int returnVal = filechooser.showSaveDialog(
					TextEditorFrame.this);
				if(returnVal == JFileChooser.APPROVE_OPTION) {
					file = filechooser.getSelectedFile();
					saveFile();
				}
			}else if( id.equals("Exit")){
				System.exit(0);
			}else if( id.equals("Cut")){
				text.cut();
			}else if( id.equals("Copy")){
				text.copy();
			}else if( id.equals("Paste")){
				text.paste();
			}else if( id.equals("Color...")){
				color = JColorChooser.showDialog( 
					TextEditorFrame.this, "", color );
				text.setForeground(color);
			}else if( id.equals("About")){
				about.setSize(100,50);
				about.setVisible(true);
			}
		}
    };

	void saveFile(){ //±£ŽæÎÄŒþ£¬œ«×Ö·ûÐŽÈëÎÄŒþ
		String content = text.getText();
		dal.save(file, content);
	}
	void openFile(){ //¶ÁÈëÎÄŒþ£¬²¢œ«×Ö·ûÖÃÈëÎÄ±Ÿ¿òÖÐ
		String content = dal.read(file);
		text.setText(content);
	}

	void initAboutDialog(){  // ³õÊŒ»¯¶Ô»°¿ò
		about.getContentPane().add( new JLabel("EditeurText V1.0") );
		about.setModal( true );  
		about.setSize(100,50 );
	}
	
	JToolBar toolbar = new JToolBar();  //¹€ŸßÌõ
	JButton [] buttons = new JButton[] {
		new JButton( "", new ImageIcon("copy.jpg") ),
		new JButton( "", new ImageIcon("cut.jpg") ),
		new JButton( "", new ImageIcon("paste.jpg") )
	};
		
	void initToolBar(){  //ŒÓÈë¹€ŸßÌõ
		for( int i=0; i<buttons.length; i++)
			toolbar.add( buttons[i] );
		buttons[0].setToolTipText( "copy" );
		buttons[0].addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent e ){
				text.copy();
			}
		});
		buttons[1].setToolTipText( "cut" );
		buttons[1].addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent e ){
				text.cut();
			}
		});
		buttons[2].setToolTipText( "paste" );
		buttons[2].addActionListener( new ActionListener(){
			public void actionPerformed( ActionEvent e ){
				text.paste();
			}
		});
		this.getContentPane().add( toolbar, BorderLayout.NORTH );
		toolbar.setRollover(true);
	}
}



//------------- Interface Ecriture et l'enregistrement ---------------
interface TextDAL {
    String read(File file);
    void save(File file, String text);
}


class FileTextDAL implements TextDAL {

    @Override
    public String read(File file) {
		logger.log(Level.INFO, "read", "read..." + file.getPath());

		try{
			FileReader fr = new FileReader( file );
			int len = (int) file.length();
			char [] buffer = new char[len];
			fr.read( buffer, 0, len );
			fr.close();
			return new String( buffer );
		}catch(Exception e ){ 
			e.printStackTrace(); 
            logger.log(Level.SEVERE, null, e);
		}
		return "";
	}

	@Override
    public void save(File file, String text) {
		logger.log(Level.INFO, "save", "save..." + file.getPath());
		try{
			FileWriter fw = new FileWriter( file );
			fw.write( text );
			fw.close();
		}catch(Exception ex ){ 
			ex.printStackTrace(); 
            logger.log(Level.SEVERE, null, ex);
		}
	}

	//ŒÓµãÈÕÖŸŽŠÀí
	Logger logger = Logger.getLogger( FileTextDAL.class.getName());
	{
		try{
			FileHandler handler = new FileHandler("TextEditorApp2.log");//¿ÉÒÔÓÃ %h/xxxx.log±íÊŸÔÚÓÃ»§Ö÷Ä¿ÂŒÏÂ
			handler.setFormatter( new SimpleFormatter());
			logger.addHandler(handler);
		}catch(IOException ex){}
	}

}


