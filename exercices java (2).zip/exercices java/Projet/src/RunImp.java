import java.util.concurrent.*;
public class RunImp implements Runnable {
  private CompteEnBanque cb;

  public RunImp(CompteEnBanque cb){
    this.cb = cb;
  }
  public void run() {
    for(int i = 0; i < 25; i++){
    	try {
    	
      if(cb.getSolde() > 0){
    	  Thread.sleep((int)(Math.random()*1000));
        cb.retraitArgent(2);
        System.out.println("Retrait effectué");
      }
      }catch(InterruptedException ex) {}                       
    }               
  }
}