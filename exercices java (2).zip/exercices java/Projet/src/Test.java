import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Livres{
	
	List<String> maListe = new ArrayList<String>();
	List<String> sign = new ArrayList<String>();
	Livres(){
		maListe.add("Ives");
		maListe.add("Laure");
		maListe.add("Dina");
		sign.add("Ives, c'est une personne morale");
		sign.add("Laure, c'est une personne morale du genre feminin ! ! !");
		sign.add("Dina, c'est une personne morale du genre feminin ! ! !");
		
	}
	Livres(String mot, String signi){
		maListe.add(mot);
		sign.add(signi);
	}
	

	public List<String> getMaListe() {
		return maListe();
	}

	public List<String> maListe() {
		maListe.add("Ives");
		maListe.add("Laure");
		maListe.add("Dina");
		maListe.add("Marie");
		return maListe;
	}

	public List<String> getSign() {
		return sign;
	}

	public  List<String> sign() {
		sign.add("Ives, c'est une personne morale");
		sign.add("Laure, c'est une personne morale du genre feminin ! ! !");
		sign.add("Dina, c'est une personne morale du genre feminin ! ! !");
		return sign;
	}
	
	void setMaListe(String mots, String signe) {
		maListe.add(mots);
		sign.add(signe);
	}

	
}

public class LivresImpl  implements Runnable{
	private Livres livre = new Livres();
	Pattern p;
	Matcher m;
	int i = 1, reponse = 1;
	Scanner sc = new Scanner(System.in);
	String mot, signe;

	public LivresImpl() {
		super();
		this.livre = livre;
		System.out.println("==========================Bienvenue dans ton livre numérique==============================\n"
				+ "======================Voici les mots qui sont dans ton livre========================");
		/**/
		
	}
	
	
	public void run() {
		try {
		for(String mots : livre.maListe) {
			p = Pattern.compile(mots);
			
			for(String s : livre.sign) {
				m = p.matcher(s);
				
				if(m.find())
					{
					 Thread.sleep((int)(Math.random()*10));
					 System.out.println(i + "."+ mots + ": "+ s);
					}
				
			 }
			i++;
			
		}
		do{
			 System.out.println("Voulez-vous ajouter un mot à votre livre?: ");
			 System.out.println("Ajoutez le mots");
			 mot = sc.nextLine();
			 System.out.println("Ajoutez la signification de ton mot :");
			 signe = sc.nextLine();
			 run(mot, signe);
			 //System.out.println(" ");
			 
			 System.out.println("Voulez-vous continuer? 1/0");
			 reponse =  sc.nextInt();
			 
			 
		 }while(reponse != 0);
	 
		 
	}catch(InterruptedException e) {}
	}
	
	
	
	
	public void run(String mots, String signe) {
		livre =  new Livres(mots, signe);
		run();
	}
	

}


public class Test {

	public static void main(String[] args) {
		
		Thread t = new Thread(new LivresImpl());
		t.start();

	}

}
