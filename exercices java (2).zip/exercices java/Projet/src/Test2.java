
public class Test2 {
public static void main(String[] args){
      int[] a=new int[10000];
 for(int i=0;i<a.length;i++){ 
 a[i]=i+2;
    }
      for(int m=1;findi(a,m)*findi(a,m)<a.length;m++){                                                                       
     for(int n=0;n<a.length;n++){                    
     if(findi(a,m)!=0){                        
     if(a[n]%(findi(a,m))==0&&a[n]!=(findi(a,m))){                                                                                      
      a[n]=0;
       }
    }
    else break;
     } 
  }
      printzheng(a);
}

public static int findi(int[] b,int m){          
int n=0;
int c=0;
for( int i=0;n<m;i++){
c++;                        
if((b[i])!=0){
n++;
 }
  }
  return b[c-1]; 
}
    public static void printzheng(int[] b){               
    for(int i=0;i<b.length;i++){
    if (b[i]!=0){
    System.out.println(b[i]);
    } 
    } 
    } 
}