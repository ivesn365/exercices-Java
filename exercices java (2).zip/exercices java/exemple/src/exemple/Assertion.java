package exemple;

public class Assertion {

	public static void main(String[] args)  {
		assert hypotenuse(3, 4) == 10 : "ERREUR";
		

	}
    static double hypotenuse(double x, double y) {
    	return Math.sqrt(x * x + x * y * y + 1);
    }
}
