package exemple;

public abstract class Canin extends Animal{
	
	void deplacement() {
		System.out.println("Je me déplace en meute!");
	}
}
