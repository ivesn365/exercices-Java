package exemple;
/* Classe interne*/

public class Englobante {
	int a;
	class Englobe{
		Englobante.this.a = 12;
		System.out.println("La valeur de a vaut : "+ a);
	}
	Englobe v = new Englobe();
	

}
