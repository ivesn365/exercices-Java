package exemple;

public abstract class Felin extends Animal{
	/* Methode se deplacer */
	void deplacement() {
		System.out.println("Je me déplace seul ");
	}

}
