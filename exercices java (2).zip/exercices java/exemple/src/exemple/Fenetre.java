package exemple;

import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;

import javax.swing.JFrame;

public class Fenetre extends JFrame {

	public Fenetre() {
		// Definit un titre pour votre fenetre
		this.setTitle("Ma premiere fenetre java");
		// Definit une taille pour celle-ci; ici, 400px de la largeur et 500 px de hauteur
		this.setSize(400, 500);
		//Nous allons maintenant dire à notre objet de se positionner au centre
		this.setLocationRelativeTo(null);
		//Ferme-toi lorsqu'on clique sur "Fermer" !
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.setVisible(true);
	}
	

}
