package exemple;

public class Mains {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Chien l = new Chien("Gris", 25);
		/*l.crier();
		l.deplacement();
		l.manger();
		l.boire();
		System.out.println(l.toString());
		// Interface
		Rintintin r = new Chien();
		r.faireCalin();
		r.faireLeBeau();
		r.faireLechouille();*/
		
		// La génériside
		Solo r = new Solo("bonjour");
		String nbr = (String)r.getValeur();
		//System.out.println(nbr);
		
		Solos<Integer> j = new Solos<Integer>(12);
		int nbr1 = j.getValeur();
		System.out.println(nbr1);

	}

}
