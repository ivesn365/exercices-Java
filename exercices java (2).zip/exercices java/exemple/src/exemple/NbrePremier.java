package exemple;

public class NbrePremier {

	public static void main(String[] args) {
		// 
		oneNumber();
	}
	
	public static void oneNumber() {
		int conteurNbre[] = {2, 3, 4, 5};
		int i = 0, j = 1, compteur = 0, k = 0, r;
		while (i <= conteurNbre.length) {
			while(j <= 10000) {
				if(j % conteurNbre[i] != 0) {
					System.out.println(j);
					
				}								
					
			
				j++; }
			i++;
		}
		
		
	}

}
