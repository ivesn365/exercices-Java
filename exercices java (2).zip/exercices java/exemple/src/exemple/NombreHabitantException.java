package exemple;

public class NombreHabitantException  extends Exception{
	NombreHabitantException(int pNbre){
		System.out.println("Le nombre d'habitant est negatif");
		System.out.println("\t ==> :" +pNbre);
	}
	
	

}

