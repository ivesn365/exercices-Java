package exemple;

public interface Rintintin {
	public void faireCalin();
	public void faireLechouille();
	public void faireLeBeau();
}
