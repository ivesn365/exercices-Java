package exemple;
/*
 * La genesité consiste à crée une class qui peut travailler avec n'importe quel type d'object*/
public class Solo {
	private Object valeur;

	public Solo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Solo(Object valeur) {
		super();
		this.valeur = valeur;
	}

	public Object getValeur() {
		return valeur;
	}

	public void setValeur(Object valeur) {
		this.valeur = valeur;
	}
  

}
