package exemple;

/*
 * */

public class Solos<T> {
	private T valeur;

	public Solos() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Solos(T valeur) {
		super();
		this.valeur = valeur;
	}

	public T getValeur() {
		return valeur;
	}

	public void setValeur(T valeur) {
		this.valeur = valeur;
	}
	

}
