package exemple;

public class StringStringBuffer {
	public static void main(String[] args) {
		String s = "", a = "bonjour";
		
		StringBuffer sb = new StringBuffer();
		final int n = 10000;
		long to = System.currentTimeMillis();
		for(int i = 0; i < n; i++) s+= a;
		long t1 = System.currentTimeMillis();
		for(int i = 0; i < n; i++) sb.append(a);
		long t2 =System.currentTimeMillis();
		System.out.println(s);
		System.out.println(sb);
		System.out.println(to - t1);
		System.out.println(t1 - t2);
	}
}
