package exemple;

import javax.swing.JFrame;

import exemple.Englobante.Englobe;

public class Test {

	public static void main(String[] args)  {
		Englobante v = new Englobante();
		Englobe v2 = new Englobe();
		
}
