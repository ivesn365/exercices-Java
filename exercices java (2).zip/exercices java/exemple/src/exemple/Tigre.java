package exemple;

public class Tigre extends Felin {

	public Tigre(String couleur, int poids) {
		this.couleur = couleur;
		this.poids = poids;
		
	}
	void crier() {
		System.out.println("Je grogne très fort !");
	}
	

}
