package exemple;

public class Ville {
	private String nomville;
	private int nombreH;
	private String nomP;
	
	public Ville() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Ville(String nomville, int nombreH, String nomP) throws NombreHabitantException{
		if(nombreH < 0) {
			throw new NombreHabitantException(nombreH);
		}else {
		this.nomville = nomville;
		this.nombreH = nombreH;
		this.nomP = nomP;
		}
	}

	public String getNomville() {
		return nomville;
	}

	public void setNomville(String nomville) {
		this.nomville = nomville;
	}

	public int getNombreH() {
		return nombreH;
	}

	public void setNombreH(int nombreH) {
		this.nombreH = nombreH;
	}

	public String getNomP() {
		return nomP;
	}

	public void setNomP(String nomP) {
		this.nomP = nomP;
	}

	@Override
	public String toString() {
		return "Ville [nomville=" + nomville + ", nombreH=" + nombreH + ", nomP=" + nomP + "]";
	}
	
	

}
