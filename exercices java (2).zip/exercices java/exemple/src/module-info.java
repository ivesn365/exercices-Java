module exemple {
	requires java.desktop;
}